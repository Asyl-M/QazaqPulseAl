package com.qazaqpulse.radio

import android.content.ComponentName
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

data class Station(val name: String, val country: String, val stream: String)

class MainActivity : ComponentActivity() {
    private var controller by mutableStateOf<MediaController?>(null)

    override fun onStart() {
        super.onStart()
        val token = SessionToken(this, ComponentName(this, RadioPlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({ controller = future.get() }, MoreExecutors.directExecutor())
    }

    override fun onStop() {
        controller?.release()
        controller = null
        super.onStop()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Color(0xFFB8A5FF), background = Color(0xFF10131B), surface = Color(0xFF1A1F2B)
            )) {
                RadioHome(controller)
            }
        }
    }
}

@Composable
fun RadioHome(controller: MediaController?) {
    var stations by remember { mutableStateOf<List<Station>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var playingName by remember { mutableStateOf("Ничего не играет") }
    var query by remember { mutableStateOf("ambient") }
    val scope = rememberCoroutineScope()

    suspend fun load(tag: String) {
        loading = true; error = null; query = tag
        try {
            stations = withContext(Dispatchers.IO) {
                val url = URL("https://de1.api.radio-browser.info/json/stations/bytag/${tag}?limit=30&hidebroken=true&order=clickcount&reverse=true")
                val connection = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 10000; readTimeout = 12000
                    setRequestProperty("User-Agent", "QazaqPulseAI/0.1")
                }
                try {
                    val json = JSONArray(connection.inputStream.bufferedReader().use { it.readText() })
                    buildList {
                        for (i in 0 until json.length()) {
                            val item = json.getJSONObject(i)
                            val stream = item.optString("url_resolved").ifBlank { item.optString("url") }
                            if (stream.startsWith("https://") && stream.isNotBlank()) {
                                add(Station(item.optString("name", "Radio"), item.optString("country", ""), stream))
                            }
                        }
                    }
                } finally { connection.disconnect() }
            }
            if (stations.isEmpty()) error = "Бұл жанрда станциялар табылмады. Басқа жанрды таңдаңыз."
        } catch (e: Exception) { error = "Станцияларды жүктеу мүмкін болмады. Интернетті тексеріңіз." }
        loading = false
    }

    LaunchedEffect(Unit) { load("ambient") }

    Column(Modifier.fillMaxSize().background(Color(0xFF10131B)).padding(20.dp)) {
        Text("QazaqPulse", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text("AI RADIO  •  YOUR SOUND, YOUR MOMENT", color = Color(0xFFB8A5FF), fontSize = 11.sp, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(24.dp))
        Text("Көңіл күйіңе сай әуен", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(2.dp), modifier = Modifier.fillMaxWidth()) {
            listOf("ambient", "jazz", "classical", "chillout", "lounge").forEach { tag ->
                TextButton(onClick = { scope.launch { load(tag) } }, contentPadding = PaddingValues(horizontal = 5.dp, vertical = 4.dp)) {
                    Text(tag, color = if (query == tag) Color.White else Color(0xFFC7B9FF), fontSize = 10.sp)
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Surface(color = Color(0xFF202637), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("ҚАЗІР ОЙНАП ТҰР", color = Color(0xFFB8A5FF), fontSize = 10.sp, letterSpacing = 1.3.sp)
                Spacer(Modifier.height(5.dp))
                Text(playingName, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = { if (controller?.isPlaying == true) controller?.pause() else controller?.play() }, enabled = controller != null) { Text(if (controller?.isPlaying == true) "Пауза" else "Ойнату") }
                    Spacer(Modifier.width(10.dp))
                    Text("Экран өшсе де ойнауды жалғастырады", color = Color.LightGray, fontSize = 10.sp)
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("Радиостанциялар", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 10.dp))
        error?.let { Text(it, color = Color(0xFFFFB4AB), modifier = Modifier.padding(8.dp)) }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(stations) { station ->
                Surface(color = Color(0xFF1A1F2B), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().clickable {
                    playingName = station.name
                    controller?.setMediaItem(MediaItem.fromUri(station.stream))
                    controller?.prepare()
                    controller?.play()
                }) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("◉", color = Color(0xFFB8A5FF), fontSize = 20.sp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(station.name, color = Color.White, fontWeight = FontWeight.Medium)
                            Text(station.country.ifBlank { "Интернет-радио" }, color = Color.Gray, fontSize = 12.sp)
                        }
                        Text("▶", color = Color(0xFFB8A5FF))
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("Станциялар Radio Browser ашық каталогынан алынады. Қолжетімділік пен эфир сапасы станцияға байланысты.", color = Color.Gray, fontSize = 10.sp)
    }
}
